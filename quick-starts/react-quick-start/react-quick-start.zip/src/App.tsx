import "./App.css";
import { useEffect, useState } from "react";
import { useWeb3AuthConnect, useWeb3AuthDisconnect } from "@web3auth/modal/react";
import { useAccount } from "wagmi";
import { SendTransaction } from "./components/sendTransaction";
import { Balance } from "./components/getBalance";
import { SwitchChain } from "./components/switchNetwork";
import { useWalletUI } from "@web3auth/modal/react";
function App() {
  const { connect, isConnected, connectorName, loading: connectLoading, error: connectError } = useWeb3AuthConnect();
  const { disconnect, loading: disconnectLoading, error: disconnectError } = useWeb3AuthDisconnect();
  const { showWalletUI, loading, error } = useWalletUI();
  const { address } = useAccount();
  const [autoLoginTriggered, setAutoLoginTriggered] = useState(false);

  useEffect(() => {
    // Wait a bit for Web3Auth to initialize, then trigger auto-login
    const timer = setTimeout(() => {
      if (!isConnected && !connectLoading && !connectError && !autoLoginTriggered) {
        connect();
        setAutoLoginTriggered(true);
      }
    }, 1000); // Wait 1 second for initialization

    return () => clearTimeout(timer);
  }, [isConnected, connectLoading, connectError, connect, autoLoginTriggered]);

  const loggedInView = (
    <div className="grid">
      <h2>Connected to {connectorName}</h2>
      <div>{address}</div>
      <div className="flex-container">
        <div>
          <button onClick={() => showWalletUI()} disabled={loading}>
            {loading ? "Opening Wallet UI..." : "Show Wallet UI"}
          </button>
          {error && <div>{error.message}</div>}
        </div>
        <div>
          <button onClick={() => disconnect()} className="card">
            Log Out
          </button>
          {disconnectLoading && <div className="loading">Disconnecting...</div>}
          {disconnectError && <div className="error">{disconnectError.message}</div>}
        </div>
      </div>
      <SendTransaction />
      <Balance />
      <SwitchChain />
    </div>
  );

  const unloggedInView = (
    <div className="grid">
      {connectLoading ? (
        <div className="loading">Opening login modal...</div>
      ) : connectError ? (
        <div>
          <div className="error">{connectError.message}</div>
          <button onClick={() => connect()} className="card">
            Retry Login
          </button>
        </div>
      ) : !autoLoginTriggered ? (
        <div className="loading">Preparing login...</div>
      ) : (
        <button onClick={() => connect()} className="card">
          Login
        </button>
      )}
    </div>

  );

  return (
    <div className="container">
      <h1 className="title">
        <a target="_blank" href="https://web3auth.io/docs/quick-start?product=Plug+and+Play&sdk=Plug+and+Play+Web+Modal+SDK&framework=React&stepIndex=0&stepIndex=0" rel="noreferrer">
          Diamond Wallet
        </a>{" "}

      </h1>

      <div className="grid">{isConnected ? loggedInView : unloggedInView}</div>
    </div>
  );
}

export default App;
